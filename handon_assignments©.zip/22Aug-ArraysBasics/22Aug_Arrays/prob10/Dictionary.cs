﻿namespace prob10
{
    internal class Dictionary
    {
    }
}