﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logicofapp
{
    public class Class1
    {

        public static void Hello()
        {
            Console.WriteLine("Hello from class library \t(logic of app project)");
        }
    }
}
