﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using logicofapp;

namespace filehandlingdemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Class1.Hello();
            Filemethods.makefile();
            Console.ReadLine();
        }
    }
}
