﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linkedlist_CL
{
    public class Single_LL
    {

        class LinkedlistNode
        {
            int data;
            LinkedlistNode next;    
        
          public LinkedlistNode(int x)
            {
                data = x;
                next = null;
            }
        }

        class UserLL { 
        
        
      
        
        }




    }
}
