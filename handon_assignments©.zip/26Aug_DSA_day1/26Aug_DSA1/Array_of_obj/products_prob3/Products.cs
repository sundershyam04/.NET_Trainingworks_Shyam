﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace products_prob3
{
    public class Products
    {
		private int _prodid;

		public int ProdId
		{
			get { return _prodid; }
			set { _prodid = value; }
		}

		private string _prodname;

		public string ProdName
		{
			get { return _prodname; }
			set { _prodname = value; }
		}



	}
}
